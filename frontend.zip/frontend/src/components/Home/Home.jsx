import React, { useState, useEffect } from "react";
import './Home.css';
import Header from "../Header/Header";
import Footer from "../Footer/Footer";
import TaskCategory from "../TaskCategory/TaskCategory";
import Modal from "../Modal/Modal";
import AddIcon from '@mui/icons-material/Add';
import SettingsIcon from '@mui/icons-material/Settings';

const Home = () => {
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [tasksByCategory, setTasksByCategory] = useState({});

  const openForm = () => {
    console.log("button clicked");
    setIsFormOpen(true);
    console.log("Form opened");
  };

  const closeForm = () => {
    setIsFormOpen(false);
    console.log("Form Closed");
    fetchTasks();
  };

  const fetchTasks = async () => {
    try {
      const response = await fetch('http://localhost:5000/tasks');
      const data = await response.json();
      const categorizedTasks = data.reduce((acc, task) => {
        acc[task.category] = acc[task.category] || [];
        acc[task.category].push(task);
        return acc;
      }, {});
      setTasksByCategory(categorizedTasks);
    } catch (error) {
      console.error("Error fetching tasks:", error);
    }
  };

  useEffect(() => {
    fetchTasks();
  }, []);

  return (
    <div className="app">
      <Header />

      <div className={`body ${isFormOpen ? "blur-background" : ""}`}>
        <div className="y">
          <div className="z">
            <div className="ea">
              <div className="fa">
                <div>Welcome To Task Manager Pro</div>
              </div>
            </div>

            <div className="ea">
              <div className="fa" onClick={openForm}>
                <div>Create a TASK</div>
                <div>
                  <AddIcon />
                </div>
              </div>
            </div>

            <TaskCategory title="Completed" tasks={tasksByCategory["Completed"]} />
          </div>

          <div className="z">
            <TaskCategory title="Important" tasks={tasksByCategory["Important"]} />
            <TaskCategory title="Work" tasks={tasksByCategory["Work"]} />
            <TaskCategory title="Personal" tasks={tasksByCategory["Personal"]} />
          </div>

          <div className="z">
            <div className="ea">
              <div className="fa">
                <div>Think think ....</div>
              </div>
            </div>
            <div className="ea">
              <div className="fa">
                <div>All the best</div>
              </div>
            </div>
            <div className="ea">
              <div className="fa">
                <div> <SettingsIcon /> </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <Footer />

      <Modal isFormOpen={isFormOpen} closeForm={closeForm} />
    </div>
  );
};

export default Home;
