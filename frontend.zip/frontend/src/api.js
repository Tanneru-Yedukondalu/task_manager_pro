// api.js
const API_URL = "http://127.0.0.1:5000"; // Your backend base URL

// Function to send a POST request to add a new task
export const addTask = async (taskData) => {
    try {
        const response = await fetch(`${API_URL}/tasks`, {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
            },
            body: JSON.stringify(taskData),
        });

        if (!response.ok) {
            throw new Error("Failed to save task.");
        }

        return response.json(); // Assuming the response is in JSON format
    } catch (error) {
        console.error("Error:", error);
        throw error;
    }
};
